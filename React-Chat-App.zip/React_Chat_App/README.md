# Update

After the new update of React, you won't be able to use CRA. But you can easily create your applications with Vite before following the video tutorial.

[Create a React App with Vite](https://github.com/safak/youtube23/tree/react-mini)
